package com.example.taskreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class Main2Activity extends AppCompatActivity {
    private TextView txtDate,txtTime;
    private int yr,mon,dy,hr,min;
    static final int DATE_DIALOG_ID=999,TIME_DIALOG_ID=998;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);SetDateAndTime();
    }

    private void SetDateAndTime() {
        txtDate=(TextView)findViewById(R.id.textViewDate);
        txtTime=(TextView)findViewById(R.id.textViewTime);

        final Calendar c=Calendar.getInstance();
        yr=c.get(Calendar.YEAR);
        mon=c.get(Calendar.MONTH);
        dy=c.get(Calendar.DAY_OF_MONTH);

        txtTime.setText(new StringBuilder().append(pad(hr)).append(":").append(pad(min)));

        txtDate.setText(new StringBuilder().append(dy).append("-").append(mon+1).append("-").append(yr).append(" "));
    }

    private String pad(int i) {
        if(i>=10)
            return String.valueOf(i);
        else
            return "0"+String.valueOf(i);
    }
    private DatePickerDialog.OnDateSetListener datePickerListener=new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
            yr=i;
            mon=i1;
            dy=i2;
            txtDate.setText(new StringBuilder().append(dy).append("-").append(mon+1).append("-").append(yr).append(" "));
        }
    };
    private TimePickerDialog.OnTimeSetListener timePickerListener=new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker timePicker, int i, int i1) {
            hr=i;
            min=i1;
            txtTime.setText(new StringBuilder().append(pad(hr)).append(":").append(pad(min)));

        }
    };
    @Override
    protected Dialog onCreateDialog(int id)
    {
        switch (id){
            case DATE_DIALOG_ID:
                return new DatePickerDialog(this,datePickerListener,yr,mon,dy);
            case TIME_DIALOG_ID:
                return new TimePickerDialog(this,timePickerListener,hr,min,false);
        }
        return null;
    }

    public void selectTime(View view) {
        showDialog(TIME_DIALOG_ID);
    }

    public void selectDate(View view) {
        showDialog(DATE_DIALOG_ID);
    }

    public void cancelButton(View view)
    {
        setResult(RESULT_CANCELED);
        finish();
    }

    public void addAppointment(View view) {

        EditText ed =(EditText)findViewById(R.id.editText);
        Spinner stype=(Spinner)findViewById(R.id.spinner);
        if(!ed.getText().toString().isEmpty()){
            Intent i=new Intent();
            i.putExtra("name",ed.getText().toString());
            i.putExtra("type",stype.getSelectedItem().toString());
            i.putExtra("monthofyear",DisplayMonthInChar(mon));
            i.putExtra("amrpm",AMorPM(hr));
            i.putExtra("dayofmonth",dy);
            i.putExtra("year",yr);
            i.putExtra("hour",formatthehour(hr));
            i.putExtra("minute",min);
            setResult(RESULT_OK,i);
            finish();
        }
        else
            Toast.makeText(this,"please enter the name!",Toast.LENGTH_LONG).show();
    }

    private String AMorPM(int i) {
        if(i>12)
            return "PM";
        else
            return "AM";
    }

    private int formatthehour(int i) {
        if(i>12)
            i-=12;
        return i;
    }

    private String DisplayMonthInChar(int i) {
        switch (i){
            case 0:
                return "Jan";
            case 1:
                return "Feb";
            case 2:
                return "Mar";
            case 3:
                return "Apr";
            case 4:
                return "May";
            case 5:
                return "Jun";
            case 6:
                return "Jul";
            case 7:
                return "Aug";
            case 8:
                return "Sept";
            case 9:
                return "Oct";
            case 10:
                return "Nov";
            case 11:
                return "Dec";
        }return "";
    }

    public void onCancel(View view) {finish();}
}


