package com.example.taskreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public ArrayList<Appointment> appointmentArrayList= new ArrayList<Appointment>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createSomeTextAppointment();
    }

    private void createSomeTextAppointment() {
        int i;
        appointmentArrayList.add(new Appointment("Doctor visit", "Health", "Dec", "AM", 18, 2019, 9, 0));
        appointmentArrayList.add(new Appointment("Hair cut", "Personal", "Dec", "PM", 20, 2019, 5, 0));
        appointmentArrayList.add(new Appointment("Birthday wishes(vinish,Ranjith)", "Other", "Dec", "AM", 21, 2019, 12, 1));
        appointmentArrayList.add(new Appointment("Meeting with Accountant", "Personal", "Dec", "PM", 22, 2019, 6, 15));
        appointmentArrayList.add(new Appointment("HR Meeting", "Work", "Jan", "AM", 2, 2020, 11, 0));
        appointmentArrayList.add(new Appointment("Professor Conference", "College", "Jan", "AM", 26, 2020, 8, 45));
        appointmentArrayList.add(new Appointment("Dinner with Priya", "Personal", "Feb", "PM", 14, 2020, 8, 30));
        appointmentArrayList.add(new Appointment("Shopping for Shadow(Dog)", "Other", "Feb", "PM", 21, 2020, 9, 30));
        appointmentArrayList.add(new Appointment("Birthday wishes(Roshan)", "Other", "Mar", "AM", 22, 2020, 12, 2));

        for (i = 0; i < appointmentArrayList.size(); i++) {
            populateTable(i);
        }
    }


    private void populateTable(int arrayListCounter) {
        TableLayout tbl=findViewById(R.id.tblTableLayout);
        TableRow tableRow=new TableRow(this);
        TableRow.LayoutParams lp=new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,TableRow.LayoutParams.WRAP_CONTENT);
        tableRow.setLayoutParams(lp);

        TextView txtName=new TextView(this);
        txtName.setLayoutParams(lp);
        txtName.setGravity(Gravity.CENTER);
        txtName.setText(appointmentArrayList.get(arrayListCounter).name);
        txtName.setWidth(140);
        txtName.setTextSize(14);

        TextView txtType=new TextView(this);
        txtType.setLayoutParams(lp);
        txtType.setGravity(Gravity.CENTER);
        txtType.setText(appointmentArrayList.get(arrayListCounter).type);
        txtType.setWidth(93);
        txtType.setTextSize(14);

        TextView txtDate=new TextView(this);
        txtDate.setLayoutParams(lp);
        txtDate.setGravity(Gravity.CENTER);
        txtDate.setText(SetDateAndTime(appointmentArrayList.get(arrayListCounter)));

        txtDate.setWidth(97);
        txtDate.setTextSize(14);

        tableRow.addView(txtName);
        tableRow.addView(txtType);
        tableRow.addView(txtDate);
        tbl.addView(tableRow,arrayListCounter+1);

    }

    private String SetDateAndTime(Appointment appointment) {
        long curDatenTime=System.currentTimeMillis();
        SimpleDateFormat formatDate=new SimpleDateFormat("MMM d,YYYY");

        String todayDate=formatDate.format(curDatenTime);
        String passDate=appointment.monDate+" "+appointment.dDate+" "+appointment.yrDate;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if(Objects.equals(todayDate,passDate)) {
                return appointment.hrDate + " " + appointment.minDate + " " + appointment.AMorPMTime;
            }
        }
        return appointment.monDate+" "+appointment.dDate+" "+appointment.yrDate;
    }

    public void nextActivity(View view){
        startActivityForResult(new Intent(this,Main2Activity.class),1542);
    }
    @Override
    public void onActivityResult(int reqC, int resC, Intent i)
    {
        super.onActivityResult(reqC,resC,i);
        if(reqC==1542 && resC==RESULT_OK && i!=null) {
            appointmentArrayList.add(new Appointment(i.getStringExtra("name"),
                    i.getStringExtra("type"), i.getStringExtra("monthofyear"),
                    i.getStringExtra("amrpm"),
                    i.getIntExtra("dayofmonth", 0), i.getIntExtra("year", 0),
                    i.getIntExtra("hour", 11), i.getIntExtra("minute", 11)));
            populateTable(appointmentArrayList.size() - 1);
            Toast.makeText(this, "Remainder is added", Toast.LENGTH_SHORT).show();

        }
    }
}