package com.example.taskreminder;

public class Appointment {
    public String name,type,monDate,AMorPMTime;
    public int dDate,yrDate,hrDate,minDate;

    public Appointment(String name,String type,String monDate,String AMorPMTime,int dDate,
                       int yrDate,int hrDate,int minDate){
        this.name=name;
        this.type=type;
        this.monDate=monDate;
        this.AMorPMTime=AMorPMTime;
        this.dDate=dDate;
        this.yrDate=yrDate;
        this.hrDate=hrDate;
        this.minDate=minDate;
    }
}